**TRUE CALLER's CALLER ID CLONE USING KOTLIN**

This project is a simple demonsteration of how can you implement truecallers caller id clone.

Here i have used broad-cast receivers to get the incoming call state and trigger a acttivity.

**Steps:**
<li>1.Setup broadcast receiver.
<li>2.Create your layout.
<li>3.Get user permissions for phone state and floating window.
<li>4.Trigger your component during a inmcoming call state through your broadcast receiver.
