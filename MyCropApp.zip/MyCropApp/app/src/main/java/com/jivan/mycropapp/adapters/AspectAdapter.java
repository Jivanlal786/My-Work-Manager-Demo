package com.jivan.mycropapp.adapters;

import android.content.Context;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;


import com.jivan.mycropapp.R;
import com.jivan.mycropapp.models.AspectRatio;
import com.jivan.mycropapp.models.RatioModel;

import java.util.Arrays;
import java.util.List;

public class AspectAdapter extends RecyclerView.Adapter<AspectAdapter.ViewHolder>{
    public int selected;
    public OnCropListener listener;
    public List<RatioModel> ratios;
    Context ctx;
    public RatioModel model;

    public interface OnCropListener {
        void onCropSelected(AspectRatio ratio);
    }

    public void setSelected(int i) {
        this.selected = i;
    }

    public AspectAdapter(Context txt) {
        ctx = txt;
        ratios = Arrays.asList(
                new RatioModel(10, 10, R.drawable.ic_crop_free, R.drawable.ic_crop_free_click, "Free"),
                new RatioModel(5, 4, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4_click,"5:4"),
                new RatioModel(1, 1, R.drawable.ic_instagram_1_1, R.drawable.ic_instagram_1_1_click,"1:1"),
                new RatioModel(4, 3, R.drawable.ic_crop_4_3, R.drawable.ic_crop_4_3_click, "4:3"),
                new RatioModel(4, 5, R.drawable.ic_instagram_4_5, R.drawable.ic_instagram_4_5_click,"4:5"),
                new RatioModel(1, 2, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4_click, "1:2"),
                new RatioModel(9, 16, R.drawable.ic_instagram_story, R.drawable.ic_instagram_story_click,"Story"),
                new RatioModel(16, 7, R.drawable.ic_movie, R.drawable.ic_movie_click,"Movie"),
                new RatioModel(2, 3, R.drawable.ic_crop_2_3, R.drawable.ic_crop_2_3_click, "2:3"),
                new RatioModel(4, 3, R.drawable.ic_fb_post, R.drawable.ic_fb_post_click, "Post"),
                new RatioModel(16, 6, R.drawable.ic_fb_cover, R.drawable.ic_fb_cover_click, "Cover"),
                new RatioModel(16, 9, R.drawable.ic_crop_16_9, R.drawable.ic_crop_16_9_click, "16:9"),
                new RatioModel(3, 2, R.drawable.ic_crop_3_2, R.drawable.ic_crop_3_2_click, "3:2"),
                new RatioModel(2, 3, R.drawable.ic_pinterest, R.drawable.ic_pinterest_click, "Post"),
                new RatioModel(16, 9, R.drawable.ic_crop_youtube, R.drawable.ic_crop_youtube_click, "Cover"),
                new RatioModel(9, 16, R.drawable.ic_crop_9_16, R.drawable.ic_crop_9_16_click, "9:16"),
                new RatioModel(3, 4, R.drawable.ic_crop_3_4, R.drawable.ic_crop_3_4_click,"3:4"),
                new RatioModel(16, 8, R.drawable.ic_crop_post_twitter, R.drawable.ic_crop_post_twitter_click, "Post"),
                new RatioModel(16, 5, R.drawable.ic_crop_header, R.drawable.ic_crop_header_click, "Header"),
                new RatioModel(10, 16, R.drawable.ic_crop_a4, R.drawable.ic_crop_a4_click, "A4"),
                new RatioModel(10, 16, R.drawable.ic_crop_a5, R.drawable.ic_crop_a5_click, "A5")
        );
        model = ratios.get(0);
    }

    public AspectAdapter(boolean z, Context txt) {
        ctx = txt;
        ratios = Arrays.asList(
                new RatioModel(1, 1, R.drawable.ic_instagram_1_1, R.drawable.ic_instagram_1_1_click,"1:1"),
                new RatioModel(5, 4, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4_click,"5:4"),
                new RatioModel(4, 3, R.drawable.ic_crop_4_3, R.drawable.ic_crop_4_3_click, "4:3"),
                new RatioModel(4, 5, R.drawable.ic_instagram_4_5, R.drawable.ic_instagram_4_5_click,"4:5"),
                new RatioModel(1, 2, R.drawable.ic_crop_5_4, R.drawable.ic_crop_5_4_click, "1:2"),
                new RatioModel(9, 16, R.drawable.ic_instagram_story, R.drawable.ic_instagram_story_click,"Story"),
                new RatioModel(16, 7, R.drawable.ic_movie, R.drawable.ic_movie_click,"Movie"),
                new RatioModel(2, 3, R.drawable.ic_crop_2_3, R.drawable.ic_crop_2_3_click, "2:3"),
                new RatioModel(4, 3, R.drawable.ic_fb_post, R.drawable.ic_fb_post_click, "Post"),
                new RatioModel(16, 6, R.drawable.ic_fb_cover, R.drawable.ic_fb_cover_click, "Cover"),
                new RatioModel(16, 9, R.drawable.ic_crop_16_9, R.drawable.ic_crop_16_9_click, "16:9"),
                new RatioModel(3, 2, R.drawable.ic_crop_3_2, R.drawable.ic_crop_3_2_click, "3:2"),
                new RatioModel(2, 3, R.drawable.ic_pinterest, R.drawable.ic_pinterest_click, "Post"),
                new RatioModel(16, 9, R.drawable.ic_crop_youtube, R.drawable.ic_crop_youtube_click, "Cover"),
                new RatioModel(9, 16, R.drawable.ic_crop_9_16, R.drawable.ic_crop_9_16_click, "9:16"),
                new RatioModel(3, 4, R.drawable.ic_crop_3_4, R.drawable.ic_crop_3_4_click,"3:4"),
                new RatioModel(16, 8, R.drawable.ic_crop_post_twitter, R.drawable.ic_crop_post_twitter_click, "Post"),
                new RatioModel(16, 5, R.drawable.ic_crop_header, R.drawable.ic_crop_header_click, "Header"),
                new RatioModel(10, 16, R.drawable.ic_crop_a4, R.drawable.ic_crop_a4_click, "A4"),
                new RatioModel(10, 16, R.drawable.ic_crop_a5, R.drawable.ic_crop_a5_click, "A5")
        );
        model = ratios.get(0);
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_crop, viewGroup, false));
    }

    public void onBindViewHolder(@NonNull ViewHolder holder, int i) {
        RatioModel model = this.ratios.get(i);
        holder.tvTitle.setText(model.getName());
        if (i == this.selected) {
            holder.ivIcon.setImageResource(model.getSelectedIem());
            holder.tvTitle.setTextColor(ctx.getResources().getColor(R.color.mainColor));
        } else {
            holder.ivIcon.setImageResource(model.getUnselectItem());
            holder.tvTitle.setTextColor(ctx.getResources().getColor(R.color.white));
        }
    }

    public void iSelected() {
        selected = 2;
        if (listener != null) {
            listener.onCropSelected(ratios.get(selected));
        }
        notifyDataSetChanged();
    }


    public int getItemCount() {
        return ratios.size();
    }

    public void setListener(OnCropListener onCropListener) {
        listener = onCropListener;
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView ivIcon;
        TextView tvTitle;
        public ViewHolder(View view) {
            super(view);
            ivIcon = view.findViewById(R.id.ivIcon);
            tvTitle = view.findViewById(R.id.tvName);
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (selected != getAdapterPosition()) {
                        model = ratios.get(getAdapterPosition());
                        selected = getAdapterPosition();
                        if (listener != null) {
                            listener.onCropSelected(model);
                        }
                        notifyDataSetChanged();
                    }
                }
            });
        }
    }
}
