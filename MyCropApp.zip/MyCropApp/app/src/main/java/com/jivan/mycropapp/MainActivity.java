package com.jivan.mycropapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.jivan.Constants;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    ImageView iv_image;
    TextView tvCrop;
    Bitmap bitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_image = findViewById(R.id.iv_image);
        tvCrop = findViewById(R.id.tv_crop);

        File image = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "1712717860458.jpg");
        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        Bitmap bitmap = BitmapFactory.decodeFile(image.getAbsolutePath(),bmOptions);
        iv_image.setImageBitmap(bitmap);


        tvCrop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent o = null;
                //get bitmap from photo and attach it here
                Utils.iBitmap = bitmap;
                o = new Intent(MainActivity.this, CropperActivity.class);
                o.putExtra(Constants.OPEN, Constants.OPEN_CROP);
                o.putExtra("iFrom", false);
                startActivityForResult(o, 900);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 900) {
            if (data != null && data.getStringExtra("done").equals("done")){
                if (Utils.iBitmap != null){
                    iv_image.setImageBitmap(Utils.iBitmap);
                }
            }
        }
    }
}