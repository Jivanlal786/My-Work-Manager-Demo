package com.jivan;


import android.content.Context;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Environment;

import com.jivan.mycropapp.R;

import java.io.File;

public class Constants {

    public static int imgWidth = 100;
    public static int imgHeight = 100;

    public static float fWidth = (imgWidth / 2.0f);
    public static float fHeight = (imgHeight / 2.0f);
    public static String yTouch = "touchY",  xTouch = "touchX";

    public static String OPEN = "openFrom";
    public static String OPEN_DRIP = "openDripItem";
    public static String OPEN_MIRROR = "openMirror";
    public static String OPEN_NEON = "openNeon";
    public static String OPEN_FRAME = "openFrame";
    public static String OPEN_BG = "openBg";
    public static String OPEN_SKETCH = "openSketch";
    public static String OPEN_PORTRAIT = "openArt";
    public static String OPEN_RATIO = "openRatio";
    public static String OPEN_PATTERN = "openPattern";
    public static String OPEN_PROFILE = "openProfile";
    public static String OPEN_MOSAIC = "openMosaic";
    public static String OPEN_COLLAGE = "openCollage";
    public static String OPEN_PIX = "openPix";
    public static String OPEN_BLUR = "openBlur";
    public static String OPEN_EXPOSURE = "openExposure";
    public static String OPEN_PAINT = "openPaint";
    public static String OPEN_FILTER = "openFilter";
    public static String KEY_OPEN_SILHOUETTE = "openSilhouette";
    public static String OPEN_CUTOUT = "openCutout";

    public static String OPEN_MOTION = "openFromMotion";
    public static String OPEN_GLITCH = "openGlitch";
    public static String OPEN_SPLASH = "openSplash";
    public static String OPEN_CROP = "openCrop";
    public static String OPEN_SKY = "openSky";
    public static String TEMP_FOLDER_NAME;

    static {
        TEMP_FOLDER_NAME = "temp";
    }
    public static String INSTAGRAM = "com.instagram.android";
    public static String TWITTER = "com.twitter.android";
    public static String WHATSAPP = "com.whatsapp";
    public static String FACEBOOK = "com.facebook.katana";
    public static Bitmap bitmapSticker = null;
    public static String rewid = null;
    public static String uri;

    static {
        String str = "";
        rewid = str;
        uri = str;
    }

    public static String getWorkspaceDirPathWithSeparator(Context context) {
        if (Build.VERSION.SDK_INT < 29)
            return Environment.getExternalStorageDirectory().getAbsolutePath() + context.getResources().getString(R.string.directory);
        else
            return context.getExternalFilesDir(Environment.DIRECTORY_PICTURES).getAbsolutePath() + File.separator;
    }

}
