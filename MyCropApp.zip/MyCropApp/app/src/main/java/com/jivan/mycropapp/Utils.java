package com.jivan.mycropapp;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Debug;

public class Utils {
    public static Bitmap iBitmap = null;
    public static String iSlash = "/";
    public static  String PNG = ".png";public static  String WEBP = ".webp";

    public static double getLeftSizeOfMemory() {
        return (Double.valueOf((double) Runtime.getRuntime().maxMemory()).doubleValue() - (Double.valueOf((double) Runtime.getRuntime().totalMemory()).doubleValue() - Double.valueOf((double) Runtime.getRuntime().freeMemory()).doubleValue())) - Double.valueOf((double) Debug.getNativeHeapAllocatedSize()).doubleValue();
    }

    public static String getLastPathSegment(String content) {
        if (content == null || content.length() == 0) {
            return "";
        }
        String[] segments = content.split("/");
        if (segments.length > 0) {
            return segments[segments.length - 1];
        }
        return "";
    }

    public static int maxSizeForSave() {
        int maxSize = (int) Math.sqrt(getLeftSizeOfMemory() / 40.0d);
        if (maxSize >1080) {
            return 1080;
        }
        return maxSize;
    }
    public static Uri getUriByResId(int resId) {
        return new Uri.Builder().scheme("res").path(String.valueOf(resId)).build();
    }
}
