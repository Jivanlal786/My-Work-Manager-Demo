package com.jivan.mycropapp;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.jivan.Constants;
import com.jivan.mycropapp.adapters.AspectAdapter;
import com.jivan.mycropapp.cropper.CropImageView;
import com.jivan.mycropapp.models.AspectRatio;

public class CropperActivity extends BaseActivity implements AspectAdapter.OnCropListener {
    private Bitmap btm;
    boolean iFrom;
    private CropImageView croppy;
    String iOpen;
    AspectAdapter adapter;
    RecyclerView rvCrop;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        iScreen();
        setContentView(R.layout.activity_cropper);
        noStatus();
        iFrom = getIntent().getExtras().getBoolean("iFrom");
        iOpen = getIntent().getStringExtra(Constants.OPEN);
        if (Utils.iBitmap != null) {
            btm = Utils.iBitmap;
        }


        adapter = new AspectAdapter(this);
        adapter.setListener(this);
        rvCrop = findViewById(R.id.ratio);
        croppy = findViewById(R.id.croppy);

        croppy.setImageBitmap(this.btm);
        croppy.setGuidelines(CropImageView.Guidelines.ON);
        croppy.setCropShape(CropImageView.CropShape.RECTANGLE);
        croppy.setScaleType(CropImageView.ScaleType.FIT_CENTER);
        croppy.setAutoZoomEnabled(true);


        rvCrop.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        rvCrop.setAdapter(adapter);

        findViewById(R.id.iLeft).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                croppy.rotateImage(-90);
            }
        });
        findViewById(R.id.iRight).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                croppy.rotateImage(90);
            }
        });
        findViewById(R.id.iVertical).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                croppy.flipImageVertically();
            }
        });

        findViewById(R.id.iHorizontal).setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                croppy.flipImageHorizontally();
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_saved, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        } else if (item.getItemId() == R.id.mSave) {
            saveImage();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }

    @Override
    public void onResume() {
        super.onResume();
    }

    public void onCropSelected(AspectRatio ratio) {
        if (ratio.getWidth() == 10 && ratio.getHeight() == 10) {
            croppy.setFixedAspectRatio(false);
        } else {
            croppy.setAspectRatio(ratio.getWidth(), ratio.getHeight());
        }
    }

    public void saveImage() {
        if (croppy.getCroppedImage() != null) {
            Utils.iBitmap = croppy.getCroppedImage();
        }
        Intent o;
        if (iOpen.equalsIgnoreCase(Constants.OPEN_CROP)) {
            o = new Intent(CropperActivity.this, MainActivity.class);
            o.putExtra("done", "done");
            setResult(RESULT_OK, o);
            if (iFrom) {
                startActivity(o);
                finish();
            } else {
                finish();
            }
        }
    }
}
