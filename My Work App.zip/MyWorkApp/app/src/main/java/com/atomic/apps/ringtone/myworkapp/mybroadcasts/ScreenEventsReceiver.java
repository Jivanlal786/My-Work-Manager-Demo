package com.atomic.apps.ringtone.myworkapp.mybroadcasts;

import static android.content.Context.ALARM_SERVICE;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.atomic.apps.ringtone.myworkapp.MainActivity;

public class ScreenEventsReceiver extends BroadcastReceiver {
    public static boolean wasScreenOn = true;
    String TAG = "JJJJJ_Scr_reciever";
    int ALARM_REQ_CODE = 1111;

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e(TAG, "ScreenEventReceiver broadcast called ");
//        if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
//            wasScreenOn = false;
//            Log.e(TAG, "ScreenEventReceiver");
//
//        } else if (intent.getAction().equals(Intent.ACTION_SCREEN_ON)) {
//            wasScreenOn = true;
//            Log.e(TAG, "ScreenEventReceiver");
//
//        }

//        Intent intent = new Intent(MainActivity.this, ScreenEventsReceiver.class);
        long triggerTime = System.currentTimeMillis() + (5 * 1000L);
        Intent intent1 = new Intent(context, ScreenEventsReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, ALARM_REQ_CODE, intent1, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        AlarmManager manager = (AlarmManager) context.getSystemService(ALARM_SERVICE);
        manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, triggerTime, triggerTime, pendingIntent);
//        manager.setExact(AlarmManager.RTC_WAKEUP, triggerTime, pendingIntent);
    }
}