package com.atomic.apps.ringtone.myworkapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.work.Constraints;
import androidx.work.NetworkType;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.atomic.apps.ringtone.myworkapp.mybroadcasts.MyService;
import com.atomic.apps.ringtone.myworkapp.mybroadcasts.MyWorker;
import com.atomic.apps.ringtone.myworkapp.mybroadcasts.ScreenEventsReceiver;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    EditText etTime;
    Button btnStart;
    int ALARM_REQ_CODE = 1111;
    WorkManager mWorkManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etTime = findViewById(R.id.et_time);
        btnStart = findViewById(R.id.btn_start);
//        Intent service = new Intent(getApplicationContext(), MyService.class);
//        startService(service) ;

//        IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
//        registerReceiver(m_ScreenOffReceiver, filter);

        mWorkManager = WorkManager.getInstance(MainActivity.this);

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                int time = Integer.parseInt(etTime.getText().toString().trim());
//                long triggerTime = System.currentTimeMillis() + (time * 1000L);
//
//                Intent intent = new Intent(MainActivity.this, ScreenEventsReceiver.class);
//
//                PendingIntent pendingIntent = PendingIntent.getBroadcast(MainActivity.this, ALARM_REQ_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
//
//                AlarmManager manager = (AlarmManager) getSystemService(ALARM_SERVICE);
//                manager.setInexactRepeating(AlarmManager.RTC_WAKEUP, triggerTime, triggerTime, pendingIntent);

                Constraints constraints = new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
                PeriodicWorkRequest request = new PeriodicWorkRequest.Builder(MyWorker.class,
                        5,
                        TimeUnit.SECONDS)
                        .setConstraints(constraints).build();
                mWorkManager.enqueue(request);
            }
        });


    }


}