package com.jivan.webviewdemo;

import android.os.Bundle;
import android.os.Environment;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.arthenica.mobileffmpeg.ExecuteCallback;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.io.File;

public class MainActivity2 extends AppCompatActivity {

    TextView tv_load, tv_reload, tv_load2, tv_reload2;
    FrameLayout banner_frame;
    AdView adView;
    String TAG = "JJJJJJJ";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
                Log.e(TAG, "onInitializationComplete: ");
            }
        });

        tv_reload = findViewById(R.id.tv_reload1);
        tv_load = findViewById(R.id.tv_load1);
        tv_reload2 = findViewById(R.id.tv_reload2);
        tv_load2 = findViewById(R.id.tv_load2);
        banner_frame = findViewById(R.id.banner_frame1);

        tv_reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                reloadBannerAd();
                // Replace the fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.banner_frame1, new BlankFragment1()); // Assuming the container for your fragments is a FrameLayout with id fragment_container
                fragmentTransaction.commit();
//                loadBanner();
            }
        });

        tv_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Replace the fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.add(R.id.banner_frame1, new BlankFragment1()); // Assuming the container for your fragments is a FrameLayout with id fragment_container
                fragmentTransaction.commit();
//                loadBanner();
            }
        });

        tv_reload2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                reloadBannerAd();
                // Replace the fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.banner_frame2, new BlankFragment2()); // Assuming the container for your fragments is a FrameLayout with id fragment_container
                fragmentTransaction.commit();
//                loadBanner();
            }
        });

        tv_load2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                // Replace the fragment
                FragmentManager fragmentManager = getSupportFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.add(R.id.banner_frame2, new BlankFragment2()); // Assuming the container for your fragments is a FrameLayout with id fragment_container
                fragmentTransaction.commit();
//                loadBanner();
            }
        });


//        concatenateVideos();
    }

    private void concatenateVideos() {
        // Input video paths
        String video1Path = Environment.getExternalStorageDirectory() + File.separator + "video1.mp4";
        String video2Path = Environment.getExternalStorageDirectory() + File.separator + "video2.mp4";

        // Output video path
        String outputVideoPath = Environment.getExternalStorageDirectory() + File.separator + "output.mp4";

        // FFmpeg command for concatenation
        String[] ffmpegCommand = {"-i", "concat:" + video1Path + "|" + video2Path, "-c", "copy", outputVideoPath};

        // Execute FFmpeg command
        FFmpeg.executeAsync(ffmpegCommand, new ExecuteCallback() {
            @Override
            public void apply(long executionId, int returnCode) {
                Log.d("FFmpeg", " return code " + returnCode);
            }
        });
//            @Override
//            public void apply(LogMessage logMessage) {
//                // Log FFmpeg output messages
//                Log.d("FFmpeg", logMessage.getText());
//            }


//            @Override
//            public void apply(LogMessage message) {
//
//            }
//        });

        // Check execution result
//        if (executionId != Config.RETURN_CODE_SUCCESS) {
//            Log.e("FFmpeg", "Error executing FFmpeg command");
//            return;
//        }

        // Wait for FFmpeg execution to finish
//        while (FFmpeg.isFFmpegCommandRunning(executionId)) {
//            // Wait for command to finish
//        }

        // Check if execution was successful
//        Statistics statistics = FFmpeg.getLastCommandOutputStatistics();
//        if (statistics != null && statistics.getVideoFrameNumber() > 0) {
//            Log.d("FFmpeg", "Video concatenation successful");
//        } else {
//            Log.e("FFmpeg", "Video concatenation failed");
//        }
    }

    private AdSize getAdSize() {
        // Determine the screen width (less decorations) to use for the ad width.
        Display display = getWindowManager().getDefaultDisplay();
        DisplayMetrics outMetrics = new DisplayMetrics();
        display.getMetrics(outMetrics);

        float density = outMetrics.density;

        float adWidthPixels = banner_frame.getWidth();

        // If the ad hasn't been laid out, default to the full screen width.
        if (adWidthPixels == 0) {
            adWidthPixels = outMetrics.widthPixels;
        }

        int adWidth = (int) (adWidthPixels / density);
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(this, adWidth);
    }

    private void loadBanner() {

        // Create a new ad view.
        adView = new AdView(this);
        adView.setAdSize(getAdSize());
        adView.setAdUnitId("ca-app-pub-3940256099942544/9214589741");

        // Replace ad container with new ad view.
        banner_frame.removeAllViews();
        banner_frame.addView(adView);

        // Start loading the ad in the background.
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
    }

    private void reloadBannerAd() {
        // Remove the current ad view from its parent
        if (adView != null && adView.getParent() != null) {
            ((ViewGroup) adView.getParent()).removeView(adView);
        }

        // Create a new ad view instance
        adView = new AdView(this);
        adView.setAdSize(AdSize.BANNER);
        adView.setAdUnitId("ca-app-pub-3940256099942544/9214589741");

        // Add the new ad view to the parent layout
        banner_frame.addView(adView);

        // Load the ad into the new ad view
        AdRequest adRequest = new AdRequest.Builder().build();
        adView.loadAd(adRequest);
        adView.setAdListener(new AdListener() {
            @Override
            public void onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            @Override
            public void onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }

            @Override
            public void onAdFailedToLoad(LoadAdError adError) {
                // Code to be executed when an ad request fails.
                Log.e(TAG, "onAdFailedToLoad: " + adError.getMessage());
            }

            @Override
            public void onAdImpression() {
                // Code to be executed when an impression is recorded
                // for an ad.
            }

            @Override
            public void onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                Log.e(TAG, "onAdLoaded: ");
            }

            @Override
            public void onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }
        });
    }
}