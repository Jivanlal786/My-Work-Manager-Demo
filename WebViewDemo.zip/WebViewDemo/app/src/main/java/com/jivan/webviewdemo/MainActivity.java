package com.jivan.webviewdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.util.SparseArray;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    TextView tvSource;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        tvSource = findViewById(R.id.tv_source);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView webView, int i) {
                if (i == 100) {
//                    linearProgressIndicator.setVisibility(8);
                }
                super.onProgressChanged(webView, i);
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            public String currentPage;

            {
                this.currentPage = webView.getUrl();
            }

//            @Override
//            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
//                if (!str.startsWith("intent")) {
//                    return super.shouldOverrideUrlLoading(webView, str);
//                }
//                return true;
//            }

//            @Override
//            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
//                if (!webResourceRequest.getUrl().toString().startsWith("intent")) {
//                    return super.shouldOverrideUrlLoading(webView, webResourceRequest);
//                }
//                return true;
//            }

//            @Override
//            public void onPageStarted(WebView webView, String str, Bitmap bitmap) {
//                super.onPageStarted(webView, str, bitmap);
//            }

//            @Override
//            public void onPageFinished(WebView webView, String str) {
//                super.onPageFinished(webView, str);
//                // When page finished loading, extract and display HTML source
//                webView.loadUrl("javascript:window.HTMLOUT.processHTML('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');");
//                webView.evaluateJavascript("(function() { return document.body.innerText; })();",
//                        value -> {
//                            // Handle the retrieved text content
//                            if (value != null) {
//                                String textContent = value.replaceAll("^\"|\"$", ""); // Remove surrounding quotes
//                                // Now you have the full text content
//                                // Handle or display the text content as needed
//                                tvSource.setText(textContent);
//                            }
//                        });
//
//            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                super.onReceivedError(view, errorCode, description, failingUrl);
                Log.e("WebView", "onReceivedError: " + errorCode + ", " + description);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Log.d("WebView", "shouldOverrideUrlLoading: " + request.getUrl().toString());
                return super.shouldOverrideUrlLoading(view, request);
            }


            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // When page finished loading, save the web archive
                saveWebArchive();
            }

//            @Override
//            public void onLoadResource(WebView webView, String str) {
//                String url = webView.getUrl();
//                if ((url.equals(this.currentPage) || url.contains("#searching"))) {
//                    return;
//                }
//                this.currentPage = url;
//            }
        });

        // Set up a JavaScript interface to receive HTML source from WebView
//        webView.addJavascriptInterface(new MyJavaScriptInterface(), "HTMLOUT");

//        webView.loadUrl("https://www.facebook.com/reel/419142420680932");
        webView.loadUrl("view-source:https://m.facebook.com/reel/419142420680932");
    }

    @Override
    protected void onResume() {
        super.onResume();

//        extractTextFromWebView();

        saveWebArchive();
    }

    // Define a JavaScript interface to receive HTML source from WebView
    private class MyJavaScriptInterface {
        @android.webkit.JavascriptInterface
        public void processHTML(String html) {
            // Update TextView with HTML source
            tvSource.setText(html);
        }
    }

    private void extractTextFromWebView() {
        // Inject JavaScript to extract text content
        webView.evaluateJavascript(
//                "(function() { return document.body.innerText; })();",
                "(function() { return document.documentElement.outerHTML; })();",
                value -> {
                    // Handle retrieved text content
                    if (value != null && !value.isEmpty()) {
//                        String textContent = value.replaceAll("^\"|\"$", ""); // Remove surrounding quotes
                        String textContent = value.replaceAll("^\"|\"$", ""); // Remove surrounding quotes
                        Log.e("JJJJJJJJJJ", "extractTextFromWebView:\n\n "+textContent);
                        tvSource.setText(textContent);
                    }
                });
    }


    private void saveWebArchive() {
        Log.e("JJJJJJJJJJ", "saveWebArchive: started archiving ");
        // Create a temporary file to save the web archive
        try {
            File file = File.createTempFile("webarchive", ".mht", getCacheDir());
            // Save the web archive
            webView.saveWebArchive(file.getAbsolutePath());
            // Read the content of the web archive file to get the original HTML code
            String htmlContent = readWebArchive(file);
            // Now you have the original HTML code
            // Handle or display the HTML code as needed
            System.out.println("Original HTML Code: " + htmlContent);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private String readWebArchive(File file) throws IOException {
        FileInputStream inputStream = new FileInputStream(file);
        byte[] buffer = new byte[(int) file.length()];
        inputStream.read(buffer);
        inputStream.close();
        return new String(buffer);
    }
}