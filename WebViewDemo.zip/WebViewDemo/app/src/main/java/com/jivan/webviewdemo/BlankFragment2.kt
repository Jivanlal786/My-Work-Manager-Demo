package com.jivan.webviewdemo

import android.os.Bundle
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.fragment.app.Fragment
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.LoadAdError

class BlankFragment2 : Fragment() {

    private var adView: AdView? = null
    private val TAG: String = "JJJJJ_Frag_1"
    var activity2: MainActivity2? = null;
    var banner_frame: FrameLayout? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        activity2 = activity as MainActivity2
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_blank2, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        banner_frame = view.findViewById(R.id.banner_frame);

        loadBanner()
    }

    private fun getAdSize(): AdSize {
        // Determine the screen width (less decorations) to use for the ad width.
        val display: Display = activity2!!.getWindowManager().getDefaultDisplay()
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = outMetrics.density
        var adWidthPixels: Float = banner_frame!!.getWidth().toFloat()

        // If the ad hasn't been laid out, default to the full screen width.
        if (adWidthPixels == 0f) {
            adWidthPixels = outMetrics.widthPixels.toFloat()
        }
        val adWidth = (adWidthPixels / density).toInt()
        return AdSize.getCurrentOrientationAnchoredAdaptiveBannerAdSize(activity2!!, adWidth)
    }

    private fun loadBanner() {

        // Create a new ad view.
        adView = AdView(activity2!!)
        adView!!.setAdSize(getAdSize())
        adView!!.setAdUnitId("ca-app-pub-3940256099942544/9214589741")

        // Replace ad container with new ad view.
        banner_frame!!.removeAllViews()
        banner_frame!!.addView(adView)

        // Start loading the ad in the background.
        val adRequest = AdRequest.Builder().build()
        adView!!.loadAd(adRequest)
    }

    private fun reloadBannerAd() {
        // Remove the current ad view from its parent
        if (adView != null && adView!!.getParent() != null) {
            (adView!!.getParent() as ViewGroup).removeView(adView)
        }

        // Create a new ad view instance
        adView = AdView(activity2!!)
        adView!!.setAdSize(AdSize.BANNER)
        adView!!.setAdUnitId("ca-app-pub-3940256099942544/9214589741")

        // Add the new ad view to the parent layout
        banner_frame!!.addView(adView)

        // Load the ad into the new ad view
        val adRequest = AdRequest.Builder().build()
        adView!!.loadAd(adRequest)
        adView!!.setAdListener(object : AdListener() {
            override fun onAdClicked() {
                // Code to be executed when the user clicks on an ad.
            }

            override fun onAdClosed() {
                // Code to be executed when the user is about to return
                // to the app after tapping on an ad.
            }

            override fun onAdFailedToLoad(adError: LoadAdError) {
                // Code to be executed when an ad request fails.
                Log.e(TAG, "onAdFailedToLoad: " + adError.message)
            }

            override fun onAdImpression() {
                // Code to be executed when an impression is recorded
                // for an ad.
            }

            override fun onAdLoaded() {
                // Code to be executed when an ad finishes loading.
                Log.e(TAG, "onAdLoaded: ")
            }

            override fun onAdOpened() {
                // Code to be executed when an ad opens an overlay that
                // covers the screen.
            }
        })
    }

}